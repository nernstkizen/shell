1) Rules features as of Jan 2014.csv:

* This file contains all the input features that are used in the rules-based score calculation. 
* ALL the features were created based on data that was available to Kaggle as of Jan 2014 or earlier. 

2) Rules features using recent and Jan 2014 data:

* This file contains all the input features that are used in the rules-based score calculation. 
* SOME of the features were created based on data that was available to Kaggle as of Jan 2014 or earlier. These features are: Core.XrdQuartz, Producer.mudPressure, Producer.oilApiGravity. These features were not updated as it was not extracted as part of our data pipeline 
* ALL OTHER features were created based on recent data available to Kaggle as of July 2014. 
* Minor differences in features that overlap between this file and the previous file are expected -- when there is more data, kriging results will change a bit. However, the correlations between these overlapping features are between 90% and 100%. 




